# lab5

In this flutter project  a users can allows for two Pokemon cards using the 
Pokemon TCG API and battle them based on their HP values. So Here, app fetches 
the two Pokemon cards, displays their images and HP and declares a winner based
on which Pokemon has teh highest HP.

Features
1. Search for Pokemon by name.
2. Fetch two random Pokemon cards using the Pokemon TCG API.
3. battle Logic: Compare the HP values and declares a winner.
4. Error handling for invalid Pokemon name.
5. User friendly UI with responsive layout.

Here I have install dependencies in the pubspec.yaml.


 Here, the app works when the  user enters the two Pokemon name in te search field 
and clicks the search button to fetch their details. Then, click battle button to compare thier HP. 
So after clicking teh battle button the highest HP is declared the winner.

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
