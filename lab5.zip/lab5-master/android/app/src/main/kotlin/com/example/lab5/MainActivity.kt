package com.example.lab5

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
